<style>
  .footerbg {
  background-color: white;
}
</style>
<footer class="footer border-top footerbg">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4">
				<!-- <div class="copyright"><?php print_lang('all rights reserved'); ?> | &copy; <?php echo SITE_NAME ?> - <?php echo date('Y') ?></div> -->
				<div class="copyright"><?php print_lang('All Rights Reserved'); ?> | &copy; Anis Saboordeen - <?php echo date('Y') ?></div>
			</div>
			<div class="col">
				<div class="footer-links text-right">
				
				</div>
			</div>
			
		<div class="col-sm-3">
			
		</div>

		</div>
	</div>
</footer>